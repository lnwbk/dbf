import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DbTool {

    private Connection connection = null;

    public DbTool() {
        System.out.println("***** DbTool Constructor ******");
        String url = "jdbc:mysql://localhost:3306/bookstore_db?serverTimezone=UTC&useSSL=false";
        String username = "root";
        String password = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Database connection successful!");

            // สร้าง table bookstore ถ้ายังไม่มี
            String sqlCreate = "CREATE TABLE IF NOT EXISTS bookstore ("
                    + "id CHAR(8) NOT NULL PRIMARY KEY,"
                    + "name VARCHAR(100) NOT NULL,"
                    + "amount INT NOT NULL,"
                    + "price INT NOT NULL"
                    + ")";
            try (PreparedStatement ps = connection.prepareStatement(sqlCreate)) {
                ps.execute();
            }

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database!");
            e.printStackTrace();
        }
    }

    // แสดงข้อมูลทั้งหมด
    public void displayAllData() {
        System.out.println("***** In Display All Data ******");
        String sql = "SELECT id, name, amount, price FROM bookstore";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.print("ID: " + rs.getString("id"));
                System.out.print(", Name: " + rs.getString("name"));
                System.out.print(", Amount: " + rs.getInt("amount"));
                System.out.println(", Price: " + rs.getInt("price"));
            }

        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }

    // เพิ่มข้อมูลหนังสือ
    public void insertData(String id, String name, int amount, int price) {
        System.out.println("***** Insert Data ******");
        String sql = "INSERT INTO bookstore (id, name, amount, price) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setInt(3, amount);
            ps.setInt(4, price);
            int rows = ps.executeUpdate();
            System.out.println("Inserted rows: " + rows);
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }

    // อัปเดตข้อมูลหนังสือ
    public void updateData(String id, String name, int amount, int price) {
        System.out.println("***** Update Data ******");
        String sql = "UPDATE bookstore SET name = ?, amount = ?, price = ? WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setInt(2, amount);
            ps.setInt(3, price);
            ps.setString(4, id);
            int rows = ps.executeUpdate();
            System.out.println("Updated rows: " + rows);
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }

    // ลบข้อมูลหนังสือ
    public void deleteData(String id) {
        System.out.println("***** Delete Data ******");
        String sql = "DELETE FROM bookstore WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, id);
            int rows = ps.executeUpdate();
            System.out.println("Deleted rows: " + rows);
        } catch (SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }

    public void closeDb() {
        System.out.println("***** Close Data ******");
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // main ทดสอบการทำงาน
    public static void main(String[] args) {
        DbTool db = new DbTool();
        db.insertData("B0000001", "Java Programming", 10, 500);
        db.displayAllData();
        db.updateData("B0000001", "Advanced Java", 5, 600);
        db.displayAllData();
        db.deleteData("B0000001");
        db.displayAllData();
        db.closeDb();
    }
}
