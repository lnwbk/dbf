public class App {
    public static void main(String[] args) {
        DbTool bookDB = new DbTool();

        // เพิ่มข้อมูลหนังสือ
        bookDB.insertData("B001", "Java Programming", 10, 350);
        bookDB.insertData("B002", "Database System", 5, 420);
        bookDB.insertData("B003", "Operating System", 0, 120);
        // แสดงข้อมูลทั้งหมด
        bookDB.displayAllData();

        // ทดสอบแก้ไขข้อมูล
        //bookDB.displayAllData();
    }
}
